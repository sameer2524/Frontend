import { Product } from './product';

export class ProductPaginData {
    Products: Product[];
    ProductCount: number;
}
