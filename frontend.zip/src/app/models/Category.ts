export class Category {
    CategoryId:number;
    DepartmentId:number;
    Name:string;
    Description:string;
}
