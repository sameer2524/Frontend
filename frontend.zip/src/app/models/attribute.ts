export class Attribute {
    AttributeName: string;
    AttributeId: number;
    AttributeValueId: number;
    AttributeValue: string;
    ProductId: number;
}
